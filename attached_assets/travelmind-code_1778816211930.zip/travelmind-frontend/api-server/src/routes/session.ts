import { Router, type IRouter } from "express";
import { randomUUID } from "crypto";

const router: IRouter = Router();

interface Trip {
  trip_id: string;
  user_id: string;
  origin: string;
  destination: string;
  departure_date: string;
  return_date: string;
  budget: number;
  currency: string;
  activities: string[];
  created_at: string;
}

const trips = new Map<string, Trip>();
const userTrips = new Map<string, string[]>();

router.post("/session/create", (req, res) => {
  const {
    origin,
    destination,
    departure_date,
    return_date,
    departureDate,
    returnDate,
    budget,
    currency,
    activities,
  } = req.body;
  const resolvedDepartureDate = departure_date || departureDate || "";
  const resolvedReturnDate = return_date || returnDate || "";

  if (!destination) {
    res.status(400).json({ error: "destination is required" });
    return;
  }

  const user_id = randomUUID();
  const trip_id = randomUUID();

  const trip: Trip = {
    trip_id,
    user_id,
    origin: origin || "Unknown",
    destination,
    departure_date: resolvedDepartureDate,
    return_date: resolvedReturnDate,
    budget: Number(budget) || 0,
    currency: currency || "USD",
    activities: Array.isArray(activities) ? activities : (activities ? String(activities).split(",").map((a: string) => a.trim()) : []),
    created_at: new Date().toISOString(),
  };

  trips.set(trip_id, trip);
  userTrips.set(user_id, [trip_id]);

  res.json({ user_id, trip_id });
});

router.get("/session/user/:userId", (req, res) => {
  const { userId } = req.params;
  const ids = userTrips.get(userId) || [];
  const result = ids.map((id) => trips.get(id)).filter(Boolean);
  res.json(result);
});

router.get("/session/:tripId", (req, res) => {
  const trip = trips.get(req.params.tripId);
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }
  res.json(trip);
});

router.post("/session/:tripId/weather", (req, res) => {
  const trip = trips.get(req.params.tripId);
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }

  res.json({
    destination: trip.destination,
    period: `${trip.departure_date} to ${trip.return_date}`,
    summary: `Weather forecast for ${trip.destination}`,
    forecast: [
      { label: "General Climate", value: `Expect moderate temperatures with possible seasonal variation in ${trip.destination}.` },
      { label: "Recommended Clothing", value: "Light layers are advised. Pack a light jacket for evenings and rain protection." },
      { label: "Best Time to Explore", value: "Morning hours are ideal for outdoor sightseeing before afternoon heat or showers." },
      { label: "UV Index", value: "Moderate to high — pack sunscreen SPF 30+." },
      { label: "Precipitation", value: "Check local forecasts closer to your travel date. Carry a compact umbrella." },
      { label: "Packing Tips", value: "Breathable fabrics, comfortable walking shoes, and a reusable water bottle are essential." },
    ],
    advisory: `Connect your Python backend (VITE_API_URL) to get live AI-powered forecasts tailored to ${trip.destination}.`,
  });
});

router.post("/session/:tripId/disruption", (req, res) => {
  const trip = trips.get(req.params.tripId);
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }

  res.json({
    destination: trip.destination,
    summary: `Travel disruption analysis for ${trip.destination}`,
    alerts: [
      { level: "info", title: "General Advisory", detail: `Check official travel advisories for ${trip.destination} before departure.` },
      { level: "info", title: "Airport Status", detail: "Verify your departure airport for any strikes, closures, or delays closer to your travel date." },
      { level: "warning", title: "Peak Season Congestion", detail: "Popular tourist destinations may experience higher-than-normal airport and road congestion during peak periods." },
      { level: "info", title: "Local Transport", detail: "Research public transport options and any planned maintenance at your destination." },
    ],
    delay_probability: "Low to Moderate",
    recommendation: "Book flexible tickets where possible and arrive at the airport at least 2.5 hours before international flights.",
  });
});

router.post("/session/:tripId/driving", (req, res) => {
  const trip = trips.get(req.params.tripId);
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }

  res.json({
    destination: trip.destination,
    summary: `Driving guide for ${trip.destination}`,
    sections: [
      { title: "License Requirements", content: `Most countries accept your national driving license for short stays. Check if ${trip.destination} requires an International Driving Permit (IDP).` },
      { title: "Road Rules", content: "Observe local speed limits, seat belt laws, and mobile phone restrictions. Penalties vary widely by country." },
      { title: "Traffic Conditions", content: `${trip.destination} city centers may experience heavy congestion during morning and evening rush hours (8-10am, 5-8pm).` },
      { title: "Parking", content: "Use designated parking zones. Download local parking apps if available. Avoid historic district centers where driving may be restricted." },
      { title: "Fuel & Electric Charging", content: "Locate fuel stations along your route in advance. EV charging infrastructure varies — check availability if driving electric." },
      { title: "Navigation Tips", content: "Download offline maps (Google Maps or Maps.me) before arrival. Mobile data roaming costs can be high." },
    ],
  });
});

router.post("/session/:tripId/cuisine", (req, res) => {
  const trip = trips.get(req.params.tripId);
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }

  res.json({
    destination: trip.destination,
    summary: `Cuisine guide for ${trip.destination}`,
    must_try: [
      `Explore local street food markets in ${trip.destination} — often the best food at the lowest price.`,
      "Ask locals for neighbourhood restaurants rather than tourist-facing eateries.",
      "Try the regional speciality dish — every destination has one worth seeking out.",
    ],
    dietary_notes: [
      { diet: "Vegetarian / Vegan", note: "Availability varies. Research local plant-based options in advance and carry translation cards for dietary needs." },
      { diet: "Allergies", note: "Cross-contamination risks are higher at street food stalls. When in doubt, ask clearly or choose certified restaurants." },
    ],
    food_safety: [
      "Drink bottled or filtered water if tap water safety is uncertain.",
      "Choose busy restaurants with visible food preparation — turnover indicates freshness.",
      "Avoid raw shellfish or salads in regions with questionable sanitation.",
    ],
    budget_tips: `At a budget of ${trip.currency} ${trip.budget}, aim for local markets and lunch specials which typically cost 40-60% less than dinner menus.`,
  });
});

router.post("/session/:tripId/culture", (req, res) => {
  const trip = trips.get(req.params.tripId);
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }

  res.json({
    destination: trip.destination,
    summary: `Cultural guide for ${trip.destination}`,
    sections: [
      { title: "Greetings", content: "Research the local greeting custom — a handshake, bow, or other gesture may be expected. When in doubt, follow the local lead." },
      { title: "Dress Code", content: `In ${trip.destination}, dress modestly when visiting religious or cultural sites. Shoulders and knees are often required to be covered.` },
      { title: "Tipping", content: "Tipping customs vary significantly. In some cultures it is expected, in others it may be considered rude. Research local norms before arriving." },
      { title: "Photography", content: "Always ask permission before photographing people. Some temples, museums, and government buildings prohibit photography entirely." },
      { title: "Public Behaviour", content: "Be aware of local norms around public displays of affection, noise levels, and queue etiquette — violations can attract negative attention or fines." },
      { title: "Local Customs", content: `${trip.destination} has unique traditions and etiquette. Engage respectfully and show curiosity — locals appreciate genuine interest in their culture.` },
    ],
  });
});

router.post("/session/:tripId/budget", (req, res) => {
  const trip = trips.get(req.params.tripId);
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }

  const departDate = trip.departure_date ? new Date(trip.departure_date) : new Date();
  const returnDate = trip.return_date ? new Date(trip.return_date) : new Date(Date.now() + 7 * 86400000);
  const tripDays = Math.max(1, Math.round((returnDate.getTime() - departDate.getTime()) / 86400000));
  const dailyBudget = trip.budget > 0 ? (trip.budget / tripDays).toFixed(0) : "N/A";

  res.json({
    destination: trip.destination,
    total_budget: trip.budget,
    currency: trip.currency,
    trip_days: tripDays,
    daily_budget: dailyBudget,
    breakdown: [
      { category: "Accommodation", percentage: 35, estimate: trip.budget > 0 ? `${trip.currency} ${(trip.budget * 0.35).toFixed(0)}` : "Varies" },
      { category: "Food & Dining", percentage: 25, estimate: trip.budget > 0 ? `${trip.currency} ${(trip.budget * 0.25).toFixed(0)}` : "Varies" },
      { category: "Transport", percentage: 20, estimate: trip.budget > 0 ? `${trip.currency} ${(trip.budget * 0.20).toFixed(0)}` : "Varies" },
      { category: "Activities & Entrance Fees", percentage: 12, estimate: trip.budget > 0 ? `${trip.currency} ${(trip.budget * 0.12).toFixed(0)}` : "Varies" },
      { category: "Shopping & Miscellaneous", percentage: 8, estimate: trip.budget > 0 ? `${trip.currency} ${(trip.budget * 0.08).toFixed(0)}` : "Varies" },
    ],
    tips: [
      "Book accommodation and flights well in advance for best rates.",
      "Use local ATMs for better exchange rates over airport currency exchanges.",
      "Consider a travel credit card with no foreign transaction fees.",
      `Set a daily spending limit of approximately ${trip.currency} ${dailyBudget} to stay on track.`,
      "Keep a 10-15% emergency buffer for unexpected expenses.",
    ],
  });
});

router.post("/session/:tripId/language", (req, res) => {
  const trip = trips.get(req.params.tripId);
  if (!trip) {
    res.status(404).json({ error: "Trip not found" });
    return;
  }

  res.json({
    destination: trip.destination,
    summary: `Language essentials for ${trip.destination}`,
    phrases: [
      { english: "Hello", local: "Hello (local equivalent)", phonetic: "Check a local phrase app for pronunciation" },
      { english: "Thank you", local: "Thank you (local)", phonetic: "Phonetic spelling varies by language" },
      { english: "Please", local: "Please (local)", phonetic: "" },
      { english: "Excuse me / Sorry", local: "Excuse me (local)", phonetic: "" },
      { english: "Where is...?", local: "Where is... (local)", phonetic: "" },
      { english: "How much does this cost?", local: "Cost question (local)", phonetic: "" },
      { english: "I need help", local: "Help (local)", phonetic: "" },
      { english: "Do you speak English?", local: "English speaker? (local)", phonetic: "" },
    ],
    tips: [
      "Download Google Translate offline language pack before your trip.",
      "Learning 5-10 basic phrases shows respect and is often warmly received.",
      "Use slow, clear speech and gestures when language barriers exist.",
      "A translation app with camera mode can help read menus and signs.",
    ],
    note: `Connect your Python backend (VITE_API_URL) to get AI-generated phrases specific to the language spoken in ${trip.destination}.`,
  });
});

export default router;
