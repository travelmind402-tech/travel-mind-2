import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { TripProvider } from "@/context/TripContext";
import NotFound from "@/pages/not-found";

import Onboarding from "@/pages/Onboarding";
import DashboardLayout from "@/pages/Dashboard";
import DashboardHome from "@/pages/DashboardHome";

import { AgentPage } from "@/components/AgentPage";
import {
  fetchWeather,
  fetchDisruption,
  fetchDriving,
  fetchCuisine,
  fetchCulture,
  fetchBudget,
  fetchLanguage,
} from "@/services/api";
import {
  Cloud,
  AlertTriangle,
  Car,
  Utensils,
  Globe,
  Wallet,
  MessageSquare,
  Info,
  ShieldAlert,
  CheckCircle,
  DollarSign,
} from "lucide-react";

// ─── Shared UI helpers ────────────────────────────────────────────────────────

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{title}</h3>
      {children}
    </div>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="space-y-2">
      {items.map((item, i) => (
        <li key={i} className="flex gap-2.5 text-sm text-muted-foreground leading-relaxed">
          <span className="mt-2 w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
          {item}
        </li>
      ))}
    </ul>
  );
}

function DataCard({ children }: { children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-xl p-6 md:p-8 shadow-sm space-y-8">
      {children}
    </div>
  );
}

// ─── Weather ─────────────────────────────────────────────────────────────────

function WeatherDisplay({ data }: { data: any }) {
  return (
    <DataCard>
      <div>
        <p className="text-2xl font-bold text-foreground">{data.destination}</p>
        {data.period && <p className="text-sm text-muted-foreground mt-1">{data.period}</p>}
      </div>

      {data.forecast?.length > 0 && (
        <Section title="Forecast">
          <div className="divide-y divide-border border border-border rounded-xl overflow-hidden">
            {data.forecast.map((item: any, i: number) => (
              <div key={i} className="flex gap-4 p-4 bg-background hover:bg-muted/30 transition-colors">
                <Cloud className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-foreground">{item.label}</p>
                  <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed">{item.value}</p>
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {data.advisory && (
        <Section title="Advisory">
          <div className="flex gap-3 p-4 bg-blue-500/5 border border-blue-500/20 rounded-lg">
            <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
            <p className="text-sm text-muted-foreground leading-relaxed">{data.advisory}</p>
          </div>
        </Section>
      )}
    </DataCard>
  );
}

// ─── Disruption ──────────────────────────────────────────────────────────────

function DisruptionDisplay({ data }: { data: any }) {
  const levelStyle: Record<string, string> = {
    info: "bg-blue-500/8 border-blue-500/25 text-blue-600 dark:text-blue-400",
    warning: "bg-amber-500/8 border-amber-500/25 text-amber-600 dark:text-amber-400",
    danger: "bg-red-500/8 border-red-500/25 text-red-600 dark:text-red-400",
  };
  const LevelIcon: Record<string, React.ElementType> = {
    info: Info,
    warning: ShieldAlert,
    danger: AlertTriangle,
  };

  return (
    <DataCard>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-2xl font-bold text-foreground">{data.destination}</p>
          <p className="text-sm text-muted-foreground mt-1">{data.summary}</p>
        </div>
        {data.delay_probability && (
          <div className="shrink-0 text-right">
            <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Delay Risk</p>
            <p className="text-lg font-bold text-foreground mt-0.5">{data.delay_probability}</p>
          </div>
        )}
      </div>

      {data.alerts?.length > 0 && (
        <Section title="Active Alerts">
          <div className="space-y-3">
            {data.alerts.map((alert: any, i: number) => {
              const style = levelStyle[alert.level] || levelStyle.info;
              const Icon = LevelIcon[alert.level] || Info;
              return (
                <div key={i} className={`flex gap-3 p-4 border rounded-xl ${style}`}>
                  <Icon className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold">{alert.title}</p>
                    <p className="text-sm opacity-75 mt-0.5 leading-relaxed">{alert.detail}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {data.recommendation && (
        <Section title="Recommendation">
          <div className="flex gap-3 p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <p className="text-sm text-muted-foreground leading-relaxed">{data.recommendation}</p>
          </div>
        </Section>
      )}
    </DataCard>
  );
}

// ─── Driving ─────────────────────────────────────────────────────────────────

function DrivingDisplay({ data }: { data: any }) {
  return (
    <DataCard>
      <p className="text-2xl font-bold text-foreground">{data.destination}</p>

      {data.sections?.length > 0 && (
        <Section title="Road Guide">
          <div className="grid sm:grid-cols-2 gap-4">
            {data.sections.map((section: any, i: number) => (
              <div key={i} className="p-4 bg-muted/30 rounded-xl border border-border">
                <p className="text-sm font-semibold text-foreground mb-1.5">{section.title}</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{section.content}</p>
              </div>
            ))}
          </div>
        </Section>
      )}
    </DataCard>
  );
}

// ─── Cuisine ─────────────────────────────────────────────────────────────────

function CuisineDisplay({ data }: { data: any }) {
  return (
    <DataCard>
      <p className="text-2xl font-bold text-foreground">{data.destination}</p>

      {data.must_try?.length > 0 && (
        <Section title="Must Try">
          <BulletList items={data.must_try} />
        </Section>
      )}

      {data.dietary_notes?.length > 0 && (
        <Section title="Dietary Considerations">
          <div className="grid sm:grid-cols-2 gap-3">
            {data.dietary_notes.map((note: any, i: number) => (
              <div key={i} className="p-4 bg-muted/40 rounded-xl border border-border">
                <p className="text-sm font-semibold text-foreground mb-1">{note.diet}</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{note.note}</p>
              </div>
            ))}
          </div>
        </Section>
      )}

      {data.food_safety?.length > 0 && (
        <Section title="Food Safety">
          <BulletList items={data.food_safety} />
        </Section>
      )}

      {data.budget_tips && (
        <Section title="Budget Tips">
          <div className="flex gap-3 p-4 bg-amber-500/5 border border-amber-500/20 rounded-xl">
            <DollarSign className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <p className="text-sm text-muted-foreground leading-relaxed">{data.budget_tips}</p>
          </div>
        </Section>
      )}
    </DataCard>
  );
}

// ─── Culture ─────────────────────────────────────────────────────────────────

function CultureDisplay({ data }: { data: any }) {
  return (
    <DataCard>
      <p className="text-2xl font-bold text-foreground">{data.destination}</p>

      {data.sections?.length > 0 && (
        <Section title="Cultural Briefing">
          <div className="grid sm:grid-cols-2 gap-4">
            {data.sections.map((section: any, i: number) => (
              <div key={i} className="p-4 bg-muted/30 rounded-xl border border-border">
                <p className="text-sm font-semibold text-foreground mb-1.5">{section.title}</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{section.content}</p>
              </div>
            ))}
          </div>
        </Section>
      )}
    </DataCard>
  );
}

// ─── Budget ──────────────────────────────────────────────────────────────────

function BudgetDisplay({ data }: { data: any }) {
  return (
    <DataCard>
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 p-5 bg-primary text-primary-foreground rounded-xl">
          <p className="text-xs font-semibold opacity-60 uppercase tracking-widest">Total Budget</p>
          <p className="text-3xl font-bold mt-1.5">
            {data.currency} {Number(data.total_budget || 0).toLocaleString()}
          </p>
          {data.trip_days && (
            <p className="text-sm opacity-70 mt-2">
              {data.trip_days} days &mdash; {data.currency} {data.daily_budget}/day
            </p>
          )}
        </div>
        <div className="p-5 bg-muted/40 border border-border rounded-xl flex flex-col justify-center">
          <p className="text-xs text-muted-foreground font-semibold uppercase tracking-widest">Currency</p>
          <p className="text-2xl font-bold text-foreground mt-1.5">{data.currency}</p>
        </div>
      </div>

      {data.breakdown?.length > 0 && (
        <Section title="Spending Breakdown">
          <div className="space-y-4">
            {data.breakdown.map((item: any, i: number) => (
              <div key={i}>
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-sm font-medium text-foreground">{item.category}</span>
                  <span className="text-sm text-muted-foreground">{item.estimate} &bull; {item.percentage}%</span>
                </div>
                <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}

      {data.tips?.length > 0 && (
        <Section title="Money Tips">
          <BulletList items={data.tips} />
        </Section>
      )}
    </DataCard>
  );
}

// ─── Language ────────────────────────────────────────────────────────────────

function LanguageDisplay({ data }: { data: any }) {
  return (
    <DataCard>
      <p className="text-2xl font-bold text-foreground">{data.destination}</p>

      {data.phrases?.length > 0 && (
        <Section title="Essential Phrases">
          <div className="border border-border rounded-xl overflow-hidden">
            <div className="grid grid-cols-3 bg-muted/60 px-4 py-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              <span>English</span>
              <span>Local</span>
              <span>Pronunciation</span>
            </div>
            {data.phrases.map((phrase: any, i: number) => (
              <div
                key={i}
                className="grid grid-cols-3 px-4 py-3.5 border-t border-border text-sm hover:bg-muted/20 transition-colors"
              >
                <span className="font-medium text-foreground">{phrase.english}</span>
                <span className="text-foreground">{phrase.local}</span>
                <span className="text-muted-foreground italic">{phrase.phonetic}</span>
              </div>
            ))}
          </div>
        </Section>
      )}

      {data.tips?.length > 0 && (
        <Section title="Communication Tips">
          <BulletList items={data.tips} />
        </Section>
      )}

      {data.note && (
        <div className="flex gap-3 p-4 bg-blue-500/5 border border-blue-500/20 rounded-xl">
          <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
          <p className="text-sm text-muted-foreground leading-relaxed">{data.note}</p>
        </div>
      )}
    </DataCard>
  );
}

// ─── Routing ─────────────────────────────────────────────────────────────────

const queryClient = new QueryClient();

function DashboardRoutes() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/dashboard" component={DashboardHome} />

        <Route path="/dashboard/weather">
          <AgentPage
            title="Weather Agent"
            description="Meteorological forecasting and optimal packing strategies."
            icon={Cloud}
            fetchData={fetchWeather}
            formatData={(data) => <WeatherDisplay data={data} />}
          />
        </Route>

        <Route path="/dashboard/disruption">
          <AgentPage
            title="Disruption Agent"
            description="Real-time monitoring of strikes, delays, and travel advisories."
            icon={AlertTriangle}
            fetchData={fetchDisruption}
            formatData={(data) => <DisruptionDisplay data={data} />}
          />
        </Route>

        <Route path="/dashboard/driving">
          <AgentPage
            title="Driving Agent"
            description="Route intelligence, local traffic laws, and parking guidance."
            icon={Car}
            fetchData={fetchDriving}
            formatData={(data) => <DrivingDisplay data={data} />}
          />
        </Route>

        <Route path="/dashboard/cuisine">
          <AgentPage
            title="Cuisine Agent"
            description="Gastronomic recommendations and dietary safety parameters."
            icon={Utensils}
            fetchData={fetchCuisine}
            formatData={(data) => <CuisineDisplay data={data} />}
          />
        </Route>

        <Route path="/dashboard/culture">
          <AgentPage
            title="Culture Agent"
            description="Local customs, etiquette protocols, and cultural taboos."
            icon={Globe}
            fetchData={fetchCulture}
            formatData={(data) => <CultureDisplay data={data} />}
          />
        </Route>

        <Route path="/dashboard/budget">
          <AgentPage
            title="Budget Agent"
            description="Financial modeling, cost breakdowns, and economic efficiency."
            icon={Wallet}
            fetchData={fetchBudget}
            formatData={(data) => <BudgetDisplay data={data} />}
          />
        </Route>

        <Route path="/dashboard/language">
          <AgentPage
            title="Language Agent"
            description="Essential linguistic phrases and phonetic communication aids."
            icon={MessageSquare}
            fetchData={fetchLanguage}
            formatData={(data) => <LanguageDisplay data={data} />}
          />
        </Route>

        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Onboarding} />
      <Route path="/dashboard/*" component={DashboardRoutes} />
      <Route path="/dashboard" component={DashboardRoutes} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <TripProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
        </TripProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
