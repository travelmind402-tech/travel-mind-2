import { ReactNode, useState, useEffect } from "react";
import { useTrip } from "@/context/TripContext";
import { useLocation } from "wouter";
import { Button } from "./ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { RefreshCw, LucideIcon } from "lucide-react";
import ReactMarkdown from "react-markdown";

interface AgentPageProps {
  title: string;
  description: string;
  icon: LucideIcon;
  fetchData: (tripId: string) => Promise<any>;
  formatData?: (data: any) => ReactNode;
}

export function AgentPage({ title, description, icon: Icon, fetchData, formatData }: AgentPageProps) {
  const { tripId } = useTrip();
  const [, setLocation] = useLocation();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!tripId) {
      setLocation("/");
    }
  }, [tripId, setLocation]);

  if (!tripId) return null;

  const handleAnalyze = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchData(tripId);
      setData(res);
    } catch (err: any) {
      setError(err.message || "Failed to fetch data");
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex flex-col items-center justify-center py-24 space-y-6">
          <div className="relative">
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-primary/20"
              animate={{ scale: [1, 1.5, 2], opacity: [1, 0.5, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeOut" }}
            />
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-primary/40"
              animate={{ scale: [1, 1.5, 2], opacity: [1, 0.5, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeOut", delay: 0.6 }}
            />
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center relative z-10">
              <Icon className="w-8 h-8 text-primary animate-pulse" />
            </div>
          </div>
          <p className="text-muted-foreground animate-pulse font-medium">Analyzing parameters...</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center py-16 text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
            <RefreshCw className="w-6 h-6 text-destructive" />
          </div>
          <div className="space-y-1">
            <p className="font-medium text-foreground">Analysis Failed</p>
            <p className="text-sm text-muted-foreground">{error}</p>
          </div>
          <Button variant="outline" onClick={handleAnalyze}>Try Again</Button>
        </div>
      );
    }

    if (data) {
      if (formatData) {
        return formatData(data);
      }
      
      const textData = typeof data === 'string' ? data : data.message || data.text || JSON.stringify(data, null, 2);
      
      return (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="prose prose-slate dark:prose-invert max-w-none w-full
                     prose-headings:font-semibold prose-headings:tracking-tight
                     prose-h3:text-lg prose-h3:mt-6 prose-h3:mb-2
                     prose-p:text-muted-foreground prose-p:leading-relaxed
                     prose-li:text-muted-foreground
                     bg-card border border-border rounded-xl p-6 md:p-8 shadow-sm"
        >
          <ReactMarkdown>{textData}</ReactMarkdown>
        </motion.div>
      );
    }

    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-6">
        <div className="w-20 h-20 rounded-full bg-primary/5 flex items-center justify-center">
          <Icon className="w-10 h-10 text-primary/40" />
        </div>
        <div className="max-w-sm space-y-2">
          <p className="text-muted-foreground">Ready to analyze your trip parameters and generate insights.</p>
        </div>
        <Button onClick={handleAnalyze} size="lg" className="px-8" data-testid={`button-analyze-${title.toLowerCase()}`}>
          Start Analysis
        </Button>
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto p-6 md:p-10 space-y-8">
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Icon className="w-5 h-5 text-primary" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">{title}</h1>
        </div>
        <p className="text-muted-foreground text-lg ml-13">{description}</p>
      </div>

      <div className="min-h-[400px]">
        <AnimatePresence mode="wait">
          {renderContent()}
        </AnimatePresence>
      </div>
    </div>
  );
}
