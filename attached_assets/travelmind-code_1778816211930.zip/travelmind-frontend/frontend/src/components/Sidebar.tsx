import { Link, useLocation } from "wouter";
import { useTrip } from "@/context/TripContext";
import {
  Cloud,
  AlertTriangle,
  Car,
  Utensils,
  Globe,
  Wallet,
  MessageSquare,
  Home,
  Plus,
  PlaneTakeoff
} from "lucide-react";
import { Button } from "./ui/button";

export function Sidebar() {
  const [location, setLocation] = useLocation();
  const { tripForm, clearSession } = useTrip();

  const links = [
    { href: "/dashboard", label: "Overview", icon: Home },
    { href: "/dashboard/weather", label: "Weather", icon: Cloud },
    { href: "/dashboard/disruption", label: "Disruptions", icon: AlertTriangle },
    { href: "/dashboard/driving", label: "Driving", icon: Car },
    { href: "/dashboard/cuisine", label: "Cuisine", icon: Utensils },
    { href: "/dashboard/culture", label: "Culture", icon: Globe },
    { href: "/dashboard/budget", label: "Budget", icon: Wallet },
    { href: "/dashboard/language", label: "Language", icon: MessageSquare },
  ];

  const handleNewTrip = () => {
    clearSession();
    setLocation("/");
  };

  return (
    <div className="w-64 border-r border-border bg-sidebar text-sidebar-foreground flex flex-col h-[100dvh] flex-shrink-0">
      <div className="p-6 border-b border-sidebar-border">
        <div className="flex items-center gap-2 mb-2 font-bold text-xl text-sidebar-primary-foreground tracking-tight">
          <PlaneTakeoff className="w-6 h-6 text-primary" />
          TravelMind
        </div>
        {tripForm && (
          <div className="text-sm text-sidebar-foreground/70 truncate">
            {tripForm.origin} &rarr; {tripForm.destination}
          </div>
        )}
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {links.map((link) => {
          const isActive = location === link.href;
          const Icon = link.icon;
          return (
            <Link key={link.href} href={link.href}>
              <div
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors ${
                  isActive
                    ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium"
                    : "hover:bg-sidebar-accent/50 text-sidebar-foreground"
                }`}
                data-testid={`link-${link.label.toLowerCase()}`}
              >
                <Icon className="w-4 h-4" />
                {link.label}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <Button
          onClick={handleNewTrip}
          variant="outline"
          className="w-full justify-start gap-2 border-sidebar-border text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground bg-transparent"
          data-testid="button-new-trip"
        >
          <Plus className="w-4 h-4" />
          New Trip
        </Button>
      </div>
    </div>
  );
}
