import { createContext, useContext, useState, ReactNode } from "react";

interface TripForm {
  destination: string;
  origin: string;
  departureDate: string;
  returnDate: string;
  budget: number;
  currency: string;
  activities: string[];
}

interface TripContextType {
  userId: string | null;
  tripId: string | null;
  tripForm: TripForm | null;
  setSession: (userId: string, tripId: string, form: TripForm) => void;
  clearSession: () => void;
}

const TripContext = createContext<TripContextType | undefined>(undefined);

export function TripProvider({ children }: { children: ReactNode }) {
  const [userId, setUserId] = useState<string | null>(null);
  const [tripId, setTripId] = useState<string | null>(null);
  const [tripForm, setTripForm] = useState<TripForm | null>(null);

  const setSession = (uId: string, tId: string, form: TripForm) => {
    setUserId(uId);
    setTripId(tId);
    setTripForm(form);
  };

  const clearSession = () => {
    setUserId(null);
    setTripId(null);
    setTripForm(null);
  };

  return (
    <TripContext.Provider
      value={{ userId, tripId, tripForm, setSession, clearSession }}
    >
      {children}
    </TripContext.Provider>
  );
}

export function useTrip() {
  const context = useContext(TripContext);
  if (context === undefined) {
    throw new Error("useTrip must be used within a TripProvider");
  }
  return context;
}
