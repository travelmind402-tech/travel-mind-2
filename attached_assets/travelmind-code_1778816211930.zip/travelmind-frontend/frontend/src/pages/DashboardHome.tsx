import { useTrip } from "@/context/TripContext";
import { useLocation, Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { MapPin, Calendar, Wallet, CheckCircle2, ArrowRight } from "lucide-react";
import { useEffect } from "react";
import { motion } from "framer-motion";

export default function DashboardHome() {
  const { tripForm, tripId } = useTrip();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!tripId) {
      setLocation("/");
    }
  }, [tripId, setLocation]);

  if (!tripForm || !tripId) return null;

  const agents = [
    { name: "Weather Analysis", path: "/dashboard/weather", desc: "Forecast & packing recommendations" },
    { name: "Disruption Alerts", path: "/dashboard/disruption", desc: "Flight status & local strikes" },
    { name: "Driving Intelligence", path: "/dashboard/driving", desc: "Road rules & conditions" },
    { name: "Cuisine Guide", path: "/dashboard/cuisine", desc: "Local dining & dietary tips" },
    { name: "Cultural Briefing", path: "/dashboard/culture", desc: "Etiquette & local customs" },
    { name: "Budget Planner", path: "/dashboard/budget", desc: "Cost breakdown & money tips" },
    { name: "Language Assistant", path: "/dashboard/language", desc: "Essential phrases & communication" },
  ];

  return (
    <div className="max-w-5xl mx-auto p-6 md:p-10 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Mission Control</h1>
        <p className="text-muted-foreground text-lg mt-2">Trip ID: <span className="font-mono text-sm bg-muted px-2 py-1 rounded">{tripId.split('-')[0]}</span></p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="col-span-1 md:col-span-2 bg-primary text-primary-foreground border-transparent shadow-md">
          <CardHeader className="pb-4">
            <CardDescription className="text-primary-foreground/70 font-medium tracking-wide uppercase text-xs">Active Deployment</CardDescription>
            <CardTitle className="text-4xl flex items-center gap-3">
              {tripForm.origin} <ArrowRight className="w-8 h-8 opacity-50" /> {tripForm.destination}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-6 mt-2">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-primary-foreground/70" />
                <span className="font-medium">{new Date(tripForm.departureDate).toLocaleDateString()} &mdash; {new Date(tripForm.returnDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-primary-foreground/70" />
                <span className="font-medium">{tripForm.budget} {tripForm.currency}</span>
              </div>
            </div>
            
            {tripForm.activities && tripForm.activities.length > 0 && (
              <div className="mt-6 pt-6 border-t border-primary-foreground/10 flex flex-wrap gap-2">
                {tripForm.activities.map((activity, i) => (
                  <span key={i} className="px-3 py-1 bg-primary-foreground/10 rounded-full text-sm">
                    {activity}
                  </span>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">System Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Session Token</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Agent Network</span>
              <span className="text-xs font-mono bg-emerald-500/10 text-emerald-600 px-2 py-0.5 rounded">ONLINE</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Data Sync</span>
              <span className="text-xs font-mono bg-emerald-500/10 text-emerald-600 px-2 py-0.5 rounded">READY</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="pt-4">
        <h2 className="text-xl font-bold tracking-tight mb-4">Available Agents</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {agents.map((agent, index) => (
            <motion.div
              key={agent.path}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Link href={agent.path}>
                <Card className="h-full hover:border-primary/50 hover:shadow-md transition-all cursor-pointer group">
                  <CardHeader className="p-5">
                    <CardTitle className="text-base group-hover:text-primary transition-colors">{agent.name}</CardTitle>
                    <CardDescription className="text-sm mt-1">{agent.desc}</CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
