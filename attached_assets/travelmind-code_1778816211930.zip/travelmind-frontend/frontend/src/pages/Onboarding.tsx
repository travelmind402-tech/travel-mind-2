import { useState } from "react";
import { useLocation } from "wouter";
import { useTrip } from "@/context/TripContext";
import { startSession } from "@/services/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PlaneTakeoff, Loader2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";

export default function Onboarding() {
  const [, setLocation] = useLocation();
  const { setSession } = useTrip();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    origin: "",
    destination: "",
    departureDate: "",
    returnDate: "",
    budgetAmount: "",
    budgetCurrency: "USD",
    activities: ""
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const payload = {
        origin: formData.origin,
        destination: formData.destination,
        departureDate: formData.departureDate,
        returnDate: formData.returnDate,
        budget: Number(formData.budgetAmount),
        currency: formData.budgetCurrency,
        activities: formData.activities.split(",").map(a => a.trim()).filter(a => a)
      };
      
      const { user_id, trip_id } = await startSession(payload);
      setSession(user_id, trip_id, payload);
      setLocation("/dashboard");
    } catch (err: any) {
      setError(err.message || "Failed to create trip session");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="flex justify-center mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-lg">
              <PlaneTakeoff className="w-6 h-6 text-primary-foreground" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">TravelMind</h1>
          </div>
        </div>

        <Card className="border-border shadow-lg">
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="text-2xl">Plan a new trip</CardTitle>
            <CardDescription>
              Initialize your personal AI travel command center
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="origin">Origin</Label>
                  <Input 
                    id="origin" 
                    name="origin" 
                    placeholder="JFK" 
                    required 
                    value={formData.origin}
                    onChange={handleChange}
                    data-testid="input-origin"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="destination">Destination</Label>
                  <Input 
                    id="destination" 
                    name="destination" 
                    placeholder="HND" 
                    required 
                    value={formData.destination}
                    onChange={handleChange}
                    data-testid="input-destination"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="departureDate">Departure Date</Label>
                  <Input 
                    id="departureDate" 
                    name="departureDate" 
                    type="date" 
                    required 
                    value={formData.departureDate}
                    onChange={handleChange}
                    data-testid="input-departure"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="returnDate">Return Date</Label>
                  <Input 
                    id="returnDate" 
                    name="returnDate" 
                    type="date" 
                    required 
                    value={formData.returnDate}
                    onChange={handleChange}
                    data-testid="input-return"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2 space-y-2">
                  <Label htmlFor="budgetAmount">Budget</Label>
                  <Input 
                    id="budgetAmount" 
                    name="budgetAmount" 
                    type="number" 
                    placeholder="5000" 
                    required 
                    value={formData.budgetAmount}
                    onChange={handleChange}
                    data-testid="input-budget-amount"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="budgetCurrency">Currency</Label>
                  <Input 
                    id="budgetCurrency" 
                    name="budgetCurrency" 
                    placeholder="USD"
                    required
                    value={formData.budgetCurrency}
                    onChange={handleChange}
                    data-testid="input-budget-currency"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="activities">Activities / Style</Label>
                <Input 
                  id="activities" 
                  name="activities" 
                  placeholder="Hiking, museums, fine dining (comma separated)" 
                  value={formData.activities}
                  onChange={handleChange}
                  data-testid="input-activities"
                />
              </div>

              {error && (
                <div className="p-3 rounded bg-destructive/10 text-destructive text-sm font-medium">
                  {error}
                </div>
              )}

              <Button 
                type="submit" 
                className="w-full mt-6" 
                disabled={loading}
                data-testid="button-submit-trip"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Initializing Agents...
                  </>
                ) : (
                  "Create Command Center"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
